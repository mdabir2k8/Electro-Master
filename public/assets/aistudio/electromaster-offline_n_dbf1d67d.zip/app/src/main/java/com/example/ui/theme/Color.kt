package com.example.ui.theme

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

/**
 * 4 Distinct App Themes:
 * 1. Dark Theme (Cyber Midnight Obsidian & Electric Neon)
 * 2. Black & White Mixed (Monochrome / High Contrast Noir)
 * 3. Liquid Glass (Translucent Frosted Glass & Aurora Neon Sheen)
 * 4. White Theme (Clean Daylight Porcelain & High-Readability Cobalt)
 */
enum class AppTheme(
    val id: String,
    val title: String,
    val subtitle: String,
    val isDark: Boolean
) {
    DARK(
        id = "dark",
        title = "Dark Theme",
        subtitle = "Cyber Midnight & Electric Blue",
        isDark = true
    ),
    BLACK_WHITE(
        id = "black_white",
        title = "Black & White Mixed",
        subtitle = "High-Contrast Monochrome & Noir",
        isDark = true
    ),
    LIQUID_GLASS(
        id = "liquid_glass",
        title = "Liquid Glass",
        subtitle = "Translucent Frosted Glass & Aurora Glow",
        isDark = true
    ),
    WHITE(
        id = "white",
        title = "White Theme",
        subtitle = "Clean Daylight Porcelain & Cobalt",
        isDark = false
    )
}

@Immutable
data class ElectroPalette(
    val background: Color,
    val surface: Color,
    val surfaceVariant: Color,
    val surfaceCard: Color,
    val surfaceElevated: Color,
    val onBackground: Color,
    val onSurface: Color,
    val onSurfaceVariant: Color,
    val onSurfaceMuted: Color,
    val primary: Color,
    val primaryGlow: Color,
    val primaryContainer: Color,
    val onPrimaryContainer: Color,
    val secondary: Color,
    val secondaryContainer: Color,
    val onSecondaryContainer: Color,
    val outline: Color,
    val outlineBright: Color,
    val navigationBar: Color,
    val accentGreen: Color,
    val accentGreenGlow: Color,
    val accentAmber: Color,
    val accentRed: Color,
    val accentPurple: Color,
    val accentGold: Color,
    val accentLead: Color,
    val accentCyan: Color,
    val isLiquidGlass: Boolean = false,
    val cardAlpha: Float = 1.0f
)

// 1. Dark Palette (Obsidian & Electric Blue)
val DarkPalette = ElectroPalette(
    background = Color(0xFF090D16),
    surface = Color(0xFF0F172A),
    surfaceVariant = Color(0xFF1E293B),
    surfaceCard = Color(0xFF131D31),
    surfaceElevated = Color(0xFF1A2642),
    onBackground = Color(0xFFF8FAFC),
    onSurface = Color(0xFFF1F5F9),
    onSurfaceVariant = Color(0xFF94A3B8),
    onSurfaceMuted = Color(0xFF64748B),
    primary = Color(0xFF38BDF8),
    primaryGlow = Color(0xFF00E5FF),
    primaryContainer = Color(0xFF0C2A4D),
    onPrimaryContainer = Color(0xFFBAE6FD),
    secondary = Color(0xFF818CF8),
    secondaryContainer = Color(0xFF23255A),
    onSecondaryContainer = Color(0xFFE0E7FF),
    outline = Color(0xFF1E293B),
    outlineBright = Color(0xFF334155),
    navigationBar = Color(0xFF090D16),
    accentGreen = Color(0xFF10B981),
    accentGreenGlow = Color(0xFF34D399),
    accentAmber = Color(0xFFF59E0B),
    accentRed = Color(0xFFEF4444),
    accentPurple = Color(0xFFA855F7),
    accentGold = Color(0xFFFBBF24),
    accentLead = Color(0xFFCBD5E1),
    accentCyan = Color(0xFF06B6D4),
    isLiquidGlass = false,
    cardAlpha = 1.0f
)

// 2. Black & White Mixed Palette (Monochrome / Noir)
val BlackWhitePalette = ElectroPalette(
    background = Color(0xFF000000), // True pitch black
    surface = Color(0xFF121212), // Pure dark graphite
    surfaceVariant = Color(0xFF1E1E1E),
    surfaceCard = Color(0xFF181818), // Matte deep gray card
    surfaceElevated = Color(0xFF262626),
    onBackground = Color(0xFFFFFFFF), // Crisp pure white
    onSurface = Color(0xFFF5F5F5),
    onSurfaceVariant = Color(0xFFB5B5B5), // Silver gray
    onSurfaceMuted = Color(0xFF757575),
    primary = Color(0xFFFFFFFF), // Pure white primary
    primaryGlow = Color(0xFFE0E0E0),
    primaryContainer = Color(0xFF2E2E2E),
    onPrimaryContainer = Color(0xFFFFFFFF),
    secondary = Color(0xFFD4D4D4),
    secondaryContainer = Color(0xFF262626),
    onSecondaryContainer = Color(0xFFEEEEEE),
    outline = Color(0xFF383838), // High contrast monochrome border
    outlineBright = Color(0xFF6E6E6E),
    navigationBar = Color(0xFF060606),
    accentGreen = Color(0xFFE5E5E5),
    accentGreenGlow = Color(0xFFFFFFFF),
    accentAmber = Color(0xFFD4D4D4),
    accentRed = Color(0xFFFFFFFF),
    accentPurple = Color(0xFFBDBDBD),
    accentGold = Color(0xFFE0E0E0),
    accentLead = Color(0xFF9E9E9E),
    accentCyan = Color(0xFFEDEDED),
    isLiquidGlass = false,
    cardAlpha = 1.0f
)

// 3. Liquid Glass Palette (Translucent Frosted Glass & Aurora Glow)
val LiquidGlassPalette = ElectroPalette(
    background = Color(0xFF070B1E), // Deep midnight ocean
    surface = Color(0xDD0F193D), // Frosted glass surface
    surfaceVariant = Color(0xCC1A2552),
    surfaceCard = Color(0xBF141E44), // Translucent glass card
    surfaceElevated = Color(0xD922336B),
    onBackground = Color(0xFFFFFFFF),
    onSurface = Color(0xFFF3F6FF),
    onSurfaceVariant = Color(0xFFAAB8E8),
    onSurfaceMuted = Color(0xFF7585B8),
    primary = Color(0xFF00F0FF), // Liquid Electric Cyan / Aqua Glow
    primaryGlow = Color(0xFF38E1FF),
    primaryContainer = Color(0x590284C7),
    onPrimaryContainer = Color(0xFFE0F7FF),
    secondary = Color(0xFFC084FC), // Liquid Neon Orchid / Violet
    secondaryContainer = Color(0x406366F1),
    onSecondaryContainer = Color(0xFFF1F5FF),
    outline = Color(0x4D00F0FF), // Glowing glass refraction edge
    outlineBright = Color(0x9900F0FF),
    navigationBar = Color(0xF2070A1E),
    accentGreen = Color(0xFF00FFB2), // Liquid Mint
    accentGreenGlow = Color(0xFF5CFFCD),
    accentAmber = Color(0xFFFFBA08),
    accentRed = Color(0xFFFF3366), // Liquid Coral
    accentPurple = Color(0xFFC084FC),
    accentGold = Color(0xFFFFD166),
    accentLead = Color(0xFF94A3B8),
    accentCyan = Color(0xFF00F0FF),
    isLiquidGlass = true,
    cardAlpha = 0.82f
)

// 4. White Theme Palette (Clean Daylight Porcelain & Cobalt)
val WhitePalette = ElectroPalette(
    background = Color(0xFFF8FAFC), // Slate 50 / Pure day
    surface = Color(0xFFFFFFFF), // Crisp pure white
    surfaceVariant = Color(0xFFF1F5F9), // Slate 100
    surfaceCard = Color(0xFFFFFFFF), // Pure white elevated card
    surfaceElevated = Color(0xFFF1F5F9), // Slate 100 chip
    onBackground = Color(0xFF0F172A), // Slate 900
    onSurface = Color(0xFF1E293B), // Slate 800
    onSurfaceVariant = Color(0xFF475569), // Slate 600
    onSurfaceMuted = Color(0xFF64748B), // Slate 500
    primary = Color(0xFF0284C7), // Cobalt Sky 600
    primaryGlow = Color(0xFF0EA5E9),
    primaryContainer = Color(0xFFE0F2FE), // Ice blue wash
    onPrimaryContainer = Color(0xFF0369A1),
    secondary = Color(0xFF4F46E5), // Indigo 600
    secondaryContainer = Color(0xFFEEF2FF),
    onSecondaryContainer = Color(0xFF3730A3),
    outline = Color(0xFFCBD5E1), // Clean border
    outlineBright = Color(0xFF94A3B8),
    navigationBar = Color(0xFFFFFFFF),
    accentGreen = Color(0xFF059669), // Emerald 600
    accentGreenGlow = Color(0xFF10B981),
    accentAmber = Color(0xFFD97706),
    accentRed = Color(0xFFDC2626),
    accentPurple = Color(0xFF7C3AED),
    accentGold = Color(0xFFB45309),
    accentLead = Color(0xFF64748B),
    accentCyan = Color(0xFF0891B2),
    isLiquidGlass = false,
    cardAlpha = 1.0f
)

/**
 * Global Theme Manager with instant reactive state and SharedPreferences persistence.
 */
object ThemeManager {
    var currentTheme by mutableStateOf(AppTheme.DARK)
        private set

    var currentPalette by mutableStateOf(DarkPalette)
        private set

    private fun resolvePalette(theme: AppTheme): ElectroPalette {
        return when (theme) {
            AppTheme.DARK -> DarkPalette
            AppTheme.BLACK_WHITE -> BlackWhitePalette
            AppTheme.LIQUID_GLASS -> LiquidGlassPalette
            AppTheme.WHITE -> WhitePalette
        }
    }

    fun setTheme(theme: AppTheme, context: Context? = null) {
        currentTheme = theme
        currentPalette = resolvePalette(theme)
        if (context != null) {
            try {
                context.getSharedPreferences("app_theme_prefs", Context.MODE_PRIVATE)
                    .edit()
                    .putString("selected_theme", theme.name)
                    .apply()
            } catch (e: Exception) {
                // Ignore persistence errors gracefully
            }
        }
    }

    fun init(context: Context) {
        try {
            val saved = context.getSharedPreferences("app_theme_prefs", Context.MODE_PRIVATE)
                .getString("selected_theme", AppTheme.DARK.name)
            currentTheme = try {
                AppTheme.valueOf(saved ?: AppTheme.DARK.name)
            } catch (e: Exception) {
                AppTheme.DARK
            }
        } catch (e: Exception) {
            currentTheme = AppTheme.DARK
        }
        currentPalette = resolvePalette(currentTheme)
    }
}

val LocalAppTheme = staticCompositionLocalOf { AppTheme.DARK }
val LocalAppPalette = staticCompositionLocalOf { DarkPalette }

// Dynamic reactive theme color getters accessed across all Compose screens
val ThemeBackground: Color get() = ThemeManager.currentPalette.background
val ThemeSurface: Color get() = ThemeManager.currentPalette.surface
val ThemeSurfaceVariant: Color get() = ThemeManager.currentPalette.surfaceVariant
val ThemeSurfaceCard: Color get() = ThemeManager.currentPalette.surfaceCard
val ThemeSurfaceElevated: Color get() = ThemeManager.currentPalette.surfaceElevated

val ThemeOnBackground: Color get() = ThemeManager.currentPalette.onBackground
val ThemeOnSurface: Color get() = ThemeManager.currentPalette.onSurface
val ThemeOnSurfaceVariant: Color get() = ThemeManager.currentPalette.onSurfaceVariant
val ThemeOnSurfaceMuted: Color get() = ThemeManager.currentPalette.onSurfaceMuted

val ThemePrimary: Color get() = ThemeManager.currentPalette.primary
val ThemePrimaryGlow: Color get() = ThemeManager.currentPalette.primaryGlow
val ThemePrimaryContainer: Color get() = ThemeManager.currentPalette.primaryContainer
val ThemeOnPrimaryContainer: Color get() = ThemeManager.currentPalette.onPrimaryContainer

val ThemeSecondary: Color get() = ThemeManager.currentPalette.secondary
val ThemeSecondaryContainer: Color get() = ThemeManager.currentPalette.secondaryContainer
val ThemeOnSecondaryContainer: Color get() = ThemeManager.currentPalette.onSecondaryContainer

val ThemeOutline: Color get() = ThemeManager.currentPalette.outline
val ThemeOutlineBright: Color get() = ThemeManager.currentPalette.outlineBright
val ThemeNavigationBar: Color get() = ThemeManager.currentPalette.navigationBar

val ThemeAccentGreen: Color get() = ThemeManager.currentPalette.accentGreen
val ThemeAccentGreenGlow: Color get() = ThemeManager.currentPalette.accentGreenGlow
val ThemeAccentAmber: Color get() = ThemeManager.currentPalette.accentAmber
val ThemeAccentRed: Color get() = ThemeManager.currentPalette.accentRed
val ThemeAccentPurple: Color get() = ThemeManager.currentPalette.accentPurple
val ThemeAccentGold: Color get() = ThemeManager.currentPalette.accentGold
val ThemeAccentLead: Color get() = ThemeManager.currentPalette.accentLead
val ThemeAccentCyan: Color get() = ThemeManager.currentPalette.accentCyan

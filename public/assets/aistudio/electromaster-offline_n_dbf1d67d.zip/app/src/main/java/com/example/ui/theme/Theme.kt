package com.example.ui.theme

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit,
) {
    val theme = ThemeManager.currentTheme
    val palette = ThemeManager.currentPalette

    val colorScheme = if (theme == AppTheme.WHITE) {
        lightColorScheme(
            background = palette.background,
            surface = palette.surface,
            surfaceVariant = palette.surfaceVariant,
            onBackground = palette.onBackground,
            onSurface = palette.onSurface,
            onSurfaceVariant = palette.onSurfaceVariant,
            primary = palette.primary,
            primaryContainer = palette.primaryContainer,
            onPrimaryContainer = palette.onPrimaryContainer,
            secondary = palette.secondary,
            secondaryContainer = palette.secondaryContainer,
            onSecondaryContainer = palette.onSecondaryContainer,
            outline = palette.outline,
            outlineVariant = palette.outlineBright,
            surfaceContainer = palette.navigationBar,
            surfaceContainerHigh = palette.surfaceCard,
            surfaceContainerHighest = palette.surfaceElevated,
            tertiary = palette.accentGreen
        )
    } else {
        darkColorScheme(
            background = palette.background,
            surface = palette.surface,
            surfaceVariant = palette.surfaceVariant,
            onBackground = palette.onBackground,
            onSurface = palette.onSurface,
            onSurfaceVariant = palette.onSurfaceVariant,
            primary = palette.primary,
            primaryContainer = palette.primaryContainer,
            onPrimaryContainer = palette.onPrimaryContainer,
            secondary = palette.secondary,
            secondaryContainer = palette.secondaryContainer,
            onSecondaryContainer = palette.onSecondaryContainer,
            outline = palette.outline,
            outlineVariant = palette.outlineBright,
            surfaceContainer = palette.navigationBar,
            surfaceContainerHigh = palette.surfaceCard,
            surfaceContainerHighest = palette.surfaceElevated,
            tertiary = palette.accentGreen
        )
    }

    CompositionLocalProvider(
        LocalAppTheme provides theme,
        LocalAppPalette provides palette
    ) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            content = content
        )
    }
}

/**
 * Reusable full-screen background container that renders standard solid colors for Dark,
 * B&W Mixed, and White themes, and a dynamic hardware-accelerated frosted aurora mesh
 * for the Liquid Glass theme.
 */
@Composable
fun AppBackgroundContainer(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    val palette = LocalAppPalette.current
    if (palette.isLiquidGlass) {
        val glassBgBrush = remember {
            Brush.verticalGradient(
                colors = listOf(
                    Color(0xFF090E24),
                    Color(0xFF0E1638),
                    Color(0xFF070B1E)
                )
            )
        }
        Box(
            modifier = modifier
                .fillMaxSize()
                .background(glassBgBrush),
            content = content
        )
    } else {
        Box(
            modifier = modifier
                .fillMaxSize()
                .background(palette.background),
            content = content
        )
    }
}

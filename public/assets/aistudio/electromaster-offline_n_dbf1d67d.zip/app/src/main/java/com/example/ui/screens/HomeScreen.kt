package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

// Pre-allocated static shapes to avoid GC pauses during scroll
private val FeatureCardShape = RoundedCornerShape(14.dp)
private val IconBoxShape = RoundedCornerShape(12.dp)
private val CategoryPillShape = RoundedCornerShape(6.dp)
private val QuickCardShape = RoundedCornerShape(16.dp)
private val QuickIconShape = RoundedCornerShape(10.dp)
private val SearchFieldShape = RoundedCornerShape(16.dp)
private val CategoryChipShape = RoundedCornerShape(12.dp)
private val CountBadgeShape = RoundedCornerShape(4.dp)

@Immutable
data class AppFeatureItem(
    val id: String,
    val title: String,
    val subtitle: String,
    val category: String,
    val icon: ImageVector,
    val accentColor: Color,
    val badges: List<String>,
    val description: String,
    val route: String
)

val allAppFeatures = listOf(
    AppFeatureItem(
        id = "resistor_color",
        title = "Resistor Color Code",
        subtitle = "4, 5 & 6-Band Graphic Analyzer",
        category = "Calculators",
        icon = Icons.Outlined.Palette,
        accentColor = Color(0xFF06B6D4),
        badges = listOf("Color Bands", "Tolerance"),
        description = "Interactive color band selector with live graphic resistor rendering, multiplier lookup, and precision tolerance calculations.",
        route = "feature_calc/0"
    ),
    AppFeatureItem(
        id = "smd_tester",
        title = "SMD Component Tester",
        subtitle = "Surface Mount Code Decoder",
        category = "Calculators",
        icon = Icons.Outlined.Memory,
        accentColor = Color(0xFF10B981),
        badges = listOf("3/4 Digit", "EIA-96"),
        description = "Decode surface mount resistors and chips with real-time ceramic SMD visual graphic and commercial tolerance verification.",
        route = "feature_calc/1"
    ),
    AppFeatureItem(
        id = "capacitor_code",
        title = "Capacitor Code Decoder",
        subtitle = "EIA 3-Digit & Unit Converter",
        category = "Calculators",
        icon = Icons.Outlined.ElectricBolt,
        accentColor = Color(0xFFF59E0B),
        badges = listOf("pF • nF • µF", "Ceramic"),
        description = "Instant 3-digit marking decoder with multi-unit conversions (pF, nF, µF) and letter tolerance ratings.",
        route = "feature_calc/2"
    ),
    AppFeatureItem(
        id = "timer_555",
        title = "555 Timer Studio",
        subtitle = "Oscillator & Pulse Designer",
        category = "Calculators",
        icon = Icons.Outlined.Timer,
        accentColor = Color(0xFF818CF8),
        badges = listOf("Astable/Mono", "Oscilloscope"),
        description = "Compute oscillation frequencies, timing intervals, and duty cycles with real-time dynamic oscilloscope square wave display.",
        route = "feature_calc/3"
    ),
    AppFeatureItem(
        id = "led_resistor",
        title = "LED Series Resistor",
        subtitle = "Current Limiting & Safety Values",
        category = "Calculators",
        icon = Icons.Outlined.Lightbulb,
        accentColor = Color(0xFFF43F5E),
        badges = listOf("Current Limit", "E12 Series"),
        description = "Design LED drive circuits with supply voltage presets, commercial standard E12 values, and safety thermal ratings.",
        route = "feature_calc/4"
    ),
    AppFeatureItem(
        id = "ohms_law",
        title = "Ohm's & Power Law",
        subtitle = "4-Parameter Dynamic Solver",
        category = "Calculators",
        icon = Icons.Outlined.Speed,
        accentColor = Color(0xFF38BDF8),
        badges = listOf("V • I • R • P", "Formulas"),
        description = "Dynamic live wheel solver: enter any two parameters to automatically calculate the remaining two with power formulas.",
        route = "feature_calc/5"
    ),
    AppFeatureItem(
        id = "microcontroller_pinouts",
        title = "Board Pinout Maps",
        subtitle = "Interactive Development Boards",
        category = "Pinouts & Hardware",
        icon = Icons.Outlined.DeveloperBoard,
        accentColor = Color(0xFF10B981),
        badges = listOf("Arduino • ESP32", "STM32 • Pico"),
        description = "Full interactive microcontroller board pinouts with category filters (Power, Digital, ADC, I2C/SPI) and quick search.",
        route = "feature_ref/0"
    ),
    AppFeatureItem(
        id = "logic_simulator",
        title = "Logic Gate Simulator",
        subtitle = "Interactive Digital Sandbox",
        category = "Simulation & Logic",
        icon = Icons.Outlined.AccountTree,
        accentColor = Color(0xFF06B6D4),
        badges = listOf("7 Gate Types", "Truth Table"),
        description = "Interactive logic simulator for AND, OR, NOT, NAND, NOR, XOR, XNOR gates with live switch inputs and glowing output LED.",
        route = "feature_ref/1"
    ),
    AppFeatureItem(
        id = "formulas_reference",
        title = "Formulas & Laws",
        subtitle = "Engineering Theory & Cheatsheet",
        category = "Theory & Reference",
        icon = Icons.Outlined.AutoStories,
        accentColor = Color(0xFFFBBF24),
        badges = listOf("Formulas", "Equations"),
        description = "Core electronic engineering principles, mathematical equations, variable definitions, and standard unit guides.",
        route = "feature_ref/2"
    ),
    AppFeatureItem(
        id = "component_catalog",
        title = "Component Directory",
        subtitle = "300+ Lab & Thesis Components",
        category = "Components",
        icon = Icons.Outlined.Widgets,
        accentColor = Color(0xFFA855F7),
        badges = listOf("300+ Items", "Pinouts & Specs"),
        description = "Comprehensive encyclopedia of 300+ components (ESP32, STM32, Sensors, ICs, Transistors, MOSFETs, Regulators, Motor Drivers, Relays, Displays) with pinouts & specs.",
        route = "feature_components"
    ),
    AppFeatureItem(
        id = "lab_settings",
        title = "Lab Settings & Config",
        subtitle = "Preferences, Precision, Themes & Screen",
        category = "Settings",
        icon = Icons.Outlined.Tune,
        accentColor = Color(0xFF38BDF8),
        badges = listOf("Themes", "Wake Lock"),
        description = "Configure lab preferences, calculator decimal precision, screen wake lock during breadboard assembly, themes, and check offline database status.",
        route = "settings"
    )
)

private data class HomeCategory(
    val key: String,
    val label: String,
    val icon: ImageVector
)

private val homeCategories = listOf(
    HomeCategory("All", "All", Icons.Outlined.Widgets),
    HomeCategory("Calculators", "Calculators", Icons.Outlined.Calculate),
    HomeCategory("Pinouts & Hardware", "Pinouts", Icons.Outlined.DeveloperBoard),
    HomeCategory("Simulation & Logic", "Logic", Icons.Outlined.AccountTree),
    HomeCategory("Theory & Reference", "Theory", Icons.Outlined.AutoStories),
    HomeCategory("Components", "Components", Icons.Outlined.Memory),
    HomeCategory("Settings", "Settings", Icons.Outlined.Tune)
)

@Composable
fun HomeScreen(
    onNavigateToFeature: (String) -> Unit,
    onOpenThemeDialog: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("All") }

    val categoryCounts = remember {
        homeCategories.associate { cat ->
            cat.key to if (cat.key == "All") allAppFeatures.size else allAppFeatures.count { it.category == cat.key }
        }
    }

    val filteredFeatures = remember(searchQuery, selectedCategory) {
        allAppFeatures.filter { feature ->
            val matchesCategory = (selectedCategory == "All") || (feature.category == selectedCategory)
            val query = searchQuery.trim().lowercase()
            val matchesQuery = query.isEmpty() ||
                    feature.title.lowercase().contains(query) ||
                    feature.subtitle.lowercase().contains(query) ||
                    feature.description.lowercase().contains(query) ||
                    feature.badges.any { it.lowercase().contains(query) }
            matchesCategory && matchesQuery
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(ThemeBackground),
        contentPadding = PaddingValues(top = 12.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // 1. Clean Welcoming Search Bar
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = {
                    Text(
                        "Search tools, formulas, pinouts...",
                        style = MaterialTheme.typography.bodyMedium,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                    )
                },
                leadingIcon = {
                    Icon(
                        Icons.Filled.Search,
                        contentDescription = "Search",
                        tint = ThemePrimary,
                        modifier = Modifier.size(20.dp)
                    )
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(
                                Icons.Filled.Close,
                                contentDescription = "Clear",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 2.dp)
                    .testTag("home_search_input"),
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = ThemeSurface,
                    unfocusedContainerColor = ThemeSurface,
                    focusedBorderColor = ThemePrimary,
                    unfocusedBorderColor = ThemeOutline,
                    focusedTextColor = MaterialTheme.colorScheme.onBackground,
                    unfocusedTextColor = MaterialTheme.colorScheme.onBackground
                ),
                singleLine = true
            )
        }

        // 2. Quick Access 4-Card Hero Grid (When not searching)
        if (searchQuery.isEmpty() && selectedCategory == "All") {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "QUICK ACCESS",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        letterSpacing = 0.8.sp,
                        modifier = Modifier.padding(bottom = 8.dp, start = 2.dp)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        QuickLaunchCard(
                            title = "Resistor Code",
                            subtitle = "Color analyzer",
                            icon = Icons.Outlined.Palette,
                            accentColor = Color(0xFF06B6D4),
                            modifier = Modifier.weight(1f),
                            onClick = { onNavigateToFeature("feature_calc/0") }
                        )
                        QuickLaunchCard(
                            title = "Board Pinouts",
                            subtitle = "Arduino • STM32",
                            icon = Icons.Outlined.DeveloperBoard,
                            accentColor = Color(0xFF10B981),
                            modifier = Modifier.weight(1f),
                            onClick = { onNavigateToFeature("feature_ref/0") }
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        QuickLaunchCard(
                            title = "Logic Simulator",
                            subtitle = "Gate sandbox",
                            icon = Icons.Outlined.AccountTree,
                            accentColor = Color(0xFF818CF8),
                            modifier = Modifier.weight(1f),
                            onClick = { onNavigateToFeature("feature_ref/1") }
                        )
                        QuickLaunchCard(
                            title = "300+ Parts",
                            subtitle = "Component catalog",
                            icon = Icons.Outlined.Widgets,
                            accentColor = Color(0xFFA855F7),
                            modifier = Modifier.weight(1f),
                            onClick = { onNavigateToFeature("feature_components") }
                        )
                    }
                }
            }
        }

        // 3. User-Friendly Clean Category Chips (Zero-allocation smooth horizontal scroll)
        item {
            val chipsScrollState = rememberScrollState()
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(chipsScrollState)
                    .padding(vertical = 4.dp, horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                homeCategories.forEach { categoryItem ->
                    val isSelected = selectedCategory == categoryItem.key
                    val count = categoryCounts[categoryItem.key] ?: 0

                    Surface(
                        shape = CategoryChipShape,
                        color = if (isSelected) ThemePrimary.copy(alpha = 0.16f) else ThemeSurface,
                        border = BorderStroke(
                            1.dp,
                            if (isSelected) ThemePrimary else ThemeOutline
                        ),
                        modifier = Modifier
                            .testTag("home_category_${categoryItem.key}")
                            .clickable { selectedCategory = categoryItem.key }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                categoryItem.icon,
                                contentDescription = null,
                                tint = if (isSelected) ThemePrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(15.dp)
                            )
                            Text(
                                text = categoryItem.label,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) ThemePrimary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Surface(
                                shape = CountBadgeShape,
                                color = if (isSelected) ThemePrimary.copy(alpha = 0.25f) else ThemeSurfaceCard,
                                modifier = Modifier.padding(start = 2.dp)
                            ) {
                                Text(
                                    text = count.toString(),
                                    modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp),
                                    style = MaterialTheme.typography.labelSmall,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) ThemePrimary else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                                )
                            }
                        }
                    }
                }
            }
        }

        // 4. Section Label
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 18.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (searchQuery.isNotEmpty()) "SEARCH RESULTS (${filteredFeatures.size})" else "ALL TOOLS & MODULES",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    letterSpacing = 0.8.sp
                )
            }
        }

        // 5. Clean, Simple, Friendly Feature Cards (Keyed & ContentType recycled)
        if (filteredFeatures.isEmpty()) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    shape = FeatureCardShape,
                    colors = CardDefaults.cardColors(containerColor = ThemeSurface),
                    border = BorderStroke(1.dp, ThemeOutline)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(28.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            Icons.Outlined.SearchOff,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(36.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "No tools match \"$searchQuery\"",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        OutlinedButton(
                            onClick = {
                                searchQuery = ""
                                selectedCategory = "All"
                            },
                            shape = CategoryPillShape,
                            border = BorderStroke(1.dp, ThemePrimary)
                        ) {
                            Text("Reset Search", color = ThemePrimary)
                        }
                    }
                }
            }
        } else {
            items(
                items = filteredFeatures,
                key = { it.id },
                contentType = { "feature_card" }
            ) { feature ->
                CleanFeatureCard(
                    feature = feature,
                    onLaunch = { onNavigateToFeature(feature.route) },
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 2.dp)
                )
            }
        }

        // 6. Subtle Theme Picker Link at Bottom
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp, bottom = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = ThemeSurface,
                    border = BorderStroke(1.dp, ThemeOutline),
                    modifier = Modifier
                        .clickable { onOpenThemeDialog() }
                        .testTag("home_bottom_theme_pill")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            Icons.Outlined.Palette,
                            contentDescription = "Theme",
                            tint = ThemePrimary,
                            modifier = Modifier.size(15.dp)
                        )
                        Text(
                            text = "Theme: ${ThemeManager.currentTheme.title}",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "• Change",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = ThemePrimary
                        )
                    }
                }
            }
        }
    }
}

/**
 * Clean, modern 2x2 Quick Launch hero card for the primary workspaces.
 */
@Composable
private fun QuickLaunchCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    accentColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        onClick = onClick,
        modifier = modifier,
        shape = QuickCardShape,
        colors = CardDefaults.cardColors(containerColor = ThemeSurface),
        border = BorderStroke(1.dp, ThemeOutline)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .background(accentColor.copy(alpha = 0.15f), QuickIconShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    icon,
                    contentDescription = title,
                    tint = accentColor,
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1
            )

            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                fontSize = 11.5.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1
            )
        }
    }
}

/**
 * Super clean, approachable, readable tool card.
 */
@Composable
private fun CleanFeatureCard(
    feature: AppFeatureItem,
    onLaunch: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        onClick = onLaunch,
        modifier = modifier
            .fillMaxWidth()
            .testTag("feature_card_${feature.id}"),
        shape = FeatureCardShape,
        colors = CardDefaults.cardColors(containerColor = ThemeSurface),
        border = BorderStroke(1.dp, ThemeOutline)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .background(feature.accentColor.copy(alpha = 0.14f), IconBoxShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    feature.icon,
                    contentDescription = feature.title,
                    tint = feature.accentColor,
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = feature.title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1
                )

                Spacer(modifier = Modifier.height(2.dp))

                Text(
                    text = feature.subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1
                )

                Spacer(modifier = Modifier.height(5.dp))

                Surface(
                    shape = CategoryPillShape,
                    color = ThemeSurfaceElevated,
                    border = BorderStroke(0.8.dp, ThemeOutline)
                ) {
                    Text(
                        text = feature.category,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        style = MaterialTheme.typography.labelSmall,
                        fontSize = 9.5.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.width(10.dp))

            Icon(
                Icons.AutoMirrored.Filled.ArrowForward,
                contentDescription = "Open",
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                modifier = Modifier.size(16.dp)
            )
        }
    }
}
